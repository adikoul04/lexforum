import { useParams, useNavigate, Link, Navigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import Spinner from '../components/Spinner';
import { useAuth } from '../contexts/AuthContext';

export default function PostPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [post, setPost] = useState(null);
  const [comments, setComments] = useState([]);
  const [commentText, setCommentText] = useState('');
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [imageError, setImageError] = useState(false);

  // fetch post + comments
  useEffect(() => {
    (async () => {
      setLoading(true);
      const { data: postData, error } = await supabase
        .from('posts')
        .select('*, author:profiles(username)')
        .eq('id', id)
        .maybeSingle();

      if (error) console.error(error);
      if (!postData) {
        setNotFound(true);
        setLoading(false);
        return;
      }
      setPost(postData);

      const { data: comm } = await supabase
        .from('comments')
        .select('*, author:profiles(username)')
        .eq('post_id', id)
        .order('created_at');
      setComments(comm ?? []);
      setLoading(false);
    })();
  }, [id]);

  if (loading) return <Spinner />;
  if (notFound) return <Navigate to="/not-found" replace />;

  const upvote = async () => {
    await supabase.from('posts').update({ upvotes: post.upvotes + 1 }).eq('id', id);
    setPost(p => ({ ...p, upvotes: p.upvotes + 1 }));
  };

  const sendComment = async () => {
    if (!user) {
      navigate('/login');
      return;
    }
    if (!commentText) return;
    const { error } = await supabase
      .from('comments')
      .insert({ post_id: id, author_id: user.id, content: commentText });
    if (error) return alert(error.message);
    setCommentText('');
    const { data: comm } = await supabase
      .from('comments')
      .select('*, author:profiles(username)')
      .eq('post_id', id)
      .order('created_at');
    setComments(comm ?? []);
  };

  const remove = async () => {
    // only author will pass RLS
    const { error } = await supabase.from('posts').delete().eq('id', id);
    if (error) return alert(error.message);
    navigate('/');
  };

  const canEdit = user && user.id === post.author_id;

  return (
    <>
      <Link to="/" className="back-button">← Back to Home</Link>
      <article className="my-4 space-y-2">
        <h1 className="text-3xl font-bold">{post.title}</h1>
        <div className="text-sm opacity-70 flex gap-2 items-center">
          <time dateTime={post.created_at}>{new Date(post.created_at).toLocaleString()}</time> •
          <span>by {post.author?.username ?? 'Unknown'}</span> •
          <span>{post.upvotes} upvotes</span>
        </div>
        {post.show_image && post.image_url && !imageError && (
          <img
            src={post.image_url}
            alt=""
            onError={() => setImageError(true)}
            className="max-h-96 w-full object-cover rounded"
          />
        )}
        <p>{post.content}</p>
      </article>

      <div className="flex gap-2 mb-4">
        <button onClick={upvote}>Upvote</button>

        {canEdit && (
          <>
            {/* EDIT button */}
            <button
              onClick={() => navigate(`/edit/${id}`)}
              className="bg-lex-gold text-lex-white rounded px-3 py-1 font-medium
                        hover:bg-lex-navy hover:text-lex-gold"
            >
              Edit
            </button>

            <button onClick={remove}>Delete</button>
          </>
        )}
      </div>

      {/* Comments */}
      <section className="space-y-4">
        <h2 className="text-xl font-semibold mb-2">Comments</h2>
        {comments.map(c => (
          <div key={c.id} className="border rounded px-3 py-2">
            <p className="text-sm opacity-70">
              {c.author?.username ?? 'Unknown'} • {new Date(c.created_at).toLocaleString()}
            </p>
            <p>{c.content}</p>
            {user && user.id === c.author_id && (
              <button
                className="text-xs underline mt-1"
                onClick={async () => {
                  const { error } = await supabase.from('comments').delete().eq('id', c.id);
                  if (!error) setComments(s => s.filter(x => x.id !== c.id));
                }}
              >
                Delete
              </button>
            )}
          </div>
        ))}

        <div className="mt-4 flex flex-col gap-2">
          <textarea
            className="border rounded p-2 min-h-[80px]"
            value={commentText}
            onChange={e => setCommentText(e.target.value)}
            placeholder={user ? 'Add a comment…' : 'Sign in to comment'}
          />
          <button
            disabled={!commentText}
            onClick={sendComment}
            className="bg-lex-gold text-lex-white rounded px-3 py-1 disabled:opacity-50"
          >
            Send
          </button>
        </div>
      </section>
    </>
  );
}
